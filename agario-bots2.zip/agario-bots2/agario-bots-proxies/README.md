# free-agario-bots

agario proxies

## Authors

### Author of bots:
NEL: https://twitter.com/0x7d2 paypal: https://paypal.me/0x7d2

### Author of this script:
Troxep: https://github.com/darkx-developer/agar.io

### Author of usage on Repl.it:
Darkx ➙ Developer

### Collaborator of bots:
jimboy3100: http://legendmod.ml

### Collaborator of bots:
xN3BULA: https://github.com/xN3BULA/free-agario-bots/

### Mega thanks for explanation:
Losbro

### Discord community of open source bots:

https://discord.gg/vqy6b5U

## Usage

* click the icon for watching the video

[![Alt text](https://img.youtube.com/vi/k4PfQNZqEUs/0.jpg)](https://www.youtube.com/watch?v=CROvbjyLmS0)

"My repl.it got banned for using proxies", the only way is node.js as explained:
https://github.com/jimboy3100/jimboy3100.github.io/tree/master/ExampleScripts/agario-bots2

Zip file for node.js
http://jimboy3100.github.io/ExampleScripts/agario-bots2/agario-bots-proxies/agar-bot-proxies.zip

## Replacing proxies.txt
Download this:

https://github.com/jimboy3100/jimboy3100.github.io/raw/master/ExampleScripts/agario-bots2/agario-bots-proxies/Gather_Proxy_9.0_Premium.zip

The above program is for replacing proxies.txt

USE ALWAYS VPN AND CONNECT ONLY TO SOCK5 SOCKETS (SAFEST)

YOU ARE NOT SAFE IF USING PROXIES AND I DO NOT KNOW HOW THIS THING WORKS

On Gather Proxy -> Proxy Checker -> Choose only SOCK5 (it takes 30 min)
Export at least 1000 ALIVE proxies (not less), see the generated file and replace everything on proxies.txt after # SOCKS5

You can also find proxy bots IPs from http://discord.gg/sK2Fkgw  , room #CHAT

** Recommended not to use other than SOCK5, also SOCK5 expire later and hide IP and countries.

### GOOD LUCK!
